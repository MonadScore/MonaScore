# Backend of MonaScore

#### How to run:

- Install: `npm i`
- Tests: `npm run test`
- Run app: `npm run start`

#### Links:

- [Account requests definition](./src/app/definitions/userRequestsDefinition.ts)
- [Account requests types](./src/types/userRequests.ts)
